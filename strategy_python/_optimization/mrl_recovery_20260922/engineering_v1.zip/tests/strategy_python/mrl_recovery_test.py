"""Recovery confirmation must stay causal, price-capped and conservatively evaluated."""

import json
from decimal import Decimal
from types import SimpleNamespace

import pytest
from nautilus_trader.backtest.engine import BacktestEngine
from nautilus_trader.backtest.models import FillModel
from nautilus_trader.config import BacktestEngineConfig, LoggingConfig
from nautilus_trader.model.data import Bar
from nautilus_trader.model.enums import AccountType, OmsType
from nautilus_trader.model.objects import Money
from nautilus_trader.test_kit.providers import TestInstrumentProvider

from strategy_python._mechanism.rules import mean_reversion_snapshot
from strategy_python._optimization.mrl_recovery_20260922.run import decision, experiments
from strategy_python.mean_reversion_long_entry_5min.preset import create_config as previous_config
from strategy_python.mean_reversion_long_recovery_5min.admission import (
    FIVE_MINUTES,
    ReclaimAdmission,
    ReclaimQuote,
    recovery_prices,
    reward_cost_allowed,
)
from strategy_python.mean_reversion_long_recovery_5min.position import EntryTarget
from strategy_python.mean_reversion_long_recovery_5min.preset import create_config
from strategy_python.mean_reversion_long_recovery_5min.strategy import (
    RecoveryMeanReversionLong5MinStrategy,
)


def bar(index, close, high):
    return SimpleNamespace(ts_end=index * FIVE_MINUTES, close=close, high=high)


def test_confirmation_freezes_prior_bands_and_only_uses_completed_recovery_high():
    model = ReclaimAdmission()
    model.update(bar(1, 101, 104), None)
    model.update(bar(2, 99, 102), (100, 110, 120))
    quote = model.update(bar(3, 103, 105), (95, 115, 135))
    assert quote.bands == (100, 110, 120) and quote.high == 105
    assert model.current(quote.created_ns - 1) is None
    assert model.current(quote.expires_ns) is None
    model.update(bar(5, 99, 105), (100, 110, 120))
    assert model.update(bar(6, 103, 105), (100, 110, 120)) is None
    model.reset()
    assert model.current(quote.created_ns) is None


@pytest.mark.parametrize("high", [105, 105.001, 105.009, 105.01])
def test_prices_require_strict_future_break_and_round_limit_to_valid_tick(high):
    quote = ReclaimQuote((100, 110, 120), 0, FIVE_MINUTES, high)
    trigger, limit = recovery_prices(quote, Decimal("0.01"), 2)
    assert trigger > Decimal(str(high))
    assert trigger - Decimal(str(high)) <= Decimal("0.01")
    assert trigger % Decimal("0.01") == limit % Decimal("0.01") == 0
    assert trigger * Decimal("1.0002") <= limit < trigger * Decimal("1.0002") + Decimal("0.01")


def test_new_price_reduces_reward_and_can_fail_cost_gate_even_when_old_entry_passed():
    quote = ReclaimQuote((100, 101, 102), 0, FIVE_MINUTES, 100.9)
    _, limit = recovery_prices(quote, Decimal("0.01"), 2)
    assert reward_cost_allowed(100, 101, 0.0005, 2, 2)
    assert not reward_cost_allowed(limit, 101, 0.0005, 2, 2)
    assert recovery_prices(ReclaimQuote((100, 101, 102), 0, 1, 101), "0.01", 2) is None


def test_control_reproduces_previous_candidate_and_risk_budget_does_not_increase():
    previous = json.loads(previous_config().json())
    control = json.loads(create_config(variant="control").json())
    for key, value in previous.items():
        assert control[key] == value, key
    assert not control["entry_recovery_breakout"]
    candidate = create_config()
    assert candidate.max_units == 1 and candidate.cycle_risk_fraction == 0.075
    assert candidate.hard_stop_distance == 0.25


@pytest.mark.parametrize(
    "path,expected", [("no_break", "EXPIRED"), ("break", "FILLED"), ("gap", "EXPIRED")]
)
@pytest.mark.parametrize("strict", [False, True])
def test_native_conditional_entry_does_not_fill_past_bar_or_beyond_cap(path, expected, strict):
    instrument = TestInstrumentProvider.ethusdt_perp_binance()
    config = create_config(asset="ETH")
    minute = FIVE_MINUTES // 5
    start = 1785542400000000000

    class Probe(RecoveryMeanReversionLong5MinStrategy):
        def on_bar(self, current):
            if hasattr(self, "submitted"):
                return
            self.submitted = current.ts_event
            self.entry_quote_expires_ns = current.ts_event + FIVE_MINUTES
            self.apply_entry_target(
                self.trade_state,
                EntryTarget(
                    direction=1,
                    role="initial",
                    quantity=Decimal("0.100"),
                    price=Decimal("2050.50"),
                    trigger_price=Decimal("2050.01"),
                    snapshot=mean_reversion_snapshot(2050.50, 2200, (1, 2, 3)),
                ),
            )

    strategy = Probe(config)
    values = [(2000, 2050, 1999, 2000)]
    following = {
        "no_break": (2000, 2050, 1999, 2000),
        "break": (2000, 2050.2, 1999, 2050.1),
        "gap": (2100, 2110, 2090, 2100),
    }[path]
    values += [following] * 7
    bars = []
    for index, prices in enumerate(values):
        ts = start + (index + 1) * minute - 1_000_000
        bars.append(
            Bar(
                config.bar_type,
                *(instrument.make_price(p) for p in prices),
                instrument.make_qty(100),
                ts,
                ts,
            )
        )
    engine = BacktestEngine(config=BacktestEngineConfig(logging=LoggingConfig(bypass_logging=True)))
    try:
        engine.add_venue(
            venue=instrument.id.venue,
            oms_type=OmsType.HEDGING,
            account_type=AccountType.MARGIN,
            base_currency=None,
            starting_balances=[Money(500, instrument.quote_currency)],
            default_leverage=Decimal(5),
            fill_model=FillModel(
                prob_fill_on_limit=0.0 if strict else 1.0,
                prob_slippage=1.0 if strict else 0.0,
                random_seed=20260922,
            ),
        )
        engine.add_instrument(instrument)
        engine.add_strategy(strategy)
        engine.add_data(bars)
        engine.run()
        orders = [o for o in engine.cache.orders() if any(":initial:" in t for t in o.tags or [])]
        assert len(orders) == 1
        order = orders[0]
        assert order.status.name == expected
        assert order.time_in_force.name == "GTD"
        for event in order.events:
            if type(event).__name__ in ("OrderTriggered", "OrderFilled"):
                assert event.ts_event > strategy.submitted
            if type(event).__name__ == "OrderFilled":
                assert event.last_px.as_decimal() <= Decimal("2050.50")
                assert event.ts_event < order.expire_time_ns
    finally:
        engine.dispose()


def test_decision_requires_both_references_and_strict_and_nontrivial_samples():
    good = {
        "net_pnl": 10,
        "review_marked_pnl": 4,
        "max_drawdown_pct": 5,
        "trades": 200,
        "review_closed_trades": 40,
        "pnl_without_best5": 2,
        "invalid_entry_orders": 0,
        "off_tick_fields": 0,
        "cashflow_error": 0,
    }
    rows = {r["id"]: dict(good) for r in experiments()}
    refs = {
        f"{a}_{v}_fee{f}": {"net_pnl": -10, "review_marked_pnl": -3, "max_drawdown_pct": 10}
        for a in ("BTC", "ETH")
        for v in ("baseline", "reclaim")
        for f in (0, 5)
    }
    assert decision(rows, refs)["passed"]
    refs["ETH_reclaim_fee0"]["net_pnl"] = 11
    assert not decision(rows, refs)["consistent_improvement"]
    rows["ETH_recovery_fee5_strict"]["net_pnl"] = -1
    assert not decision(rows, refs)["passed"]
    rows["ETH_recovery_fee5_strict"]["net_pnl"] = 10
    rows["BTC_recovery_fee0"]["trades"] = 0
    assert not decision(rows, refs)["passed"]
