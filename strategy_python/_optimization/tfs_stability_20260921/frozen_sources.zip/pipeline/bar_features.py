"""按 UTC 日物化行情特征；标准 Bar 与特征分别存储，支持跨日续算和按列读取。"""

from __future__ import annotations

import hashlib
import json
import os
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from tempfile import NamedTemporaryFile

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from nautilus_trader.core.data import Data
from nautilus_trader.model.custom import customdataclass
from nautilus_trader.model.data import Bar, BarType
from nautilus_trader.model.identifiers import InstrumentId
from nautilus_trader.persistence.catalog import ParquetDataCatalog
from nautilus_trader.persistence.catalog.parquet import (
    _parse_filename_timestamps,
    _timestamps_to_filename,
)

from pipeline.convert_binance_bars import (
    ConversionError,
    read_archive_checksum,
    read_record,
    record_path_for,
)
from pipeline.convert_binance_trades import CSV_CHUNK_ROWS, iter_trade_archive
from pipeline.models import SyncedArchive, as_utc, bar_type_for, interval_delta, normalize_symbol
from pipeline.validate_data import DataValidationError

FEATURE_VERSION = 1
DAY_NS = 86_400_000_000_000
BASE_COLUMNS = (
    "open",
    "high",
    "low",
    "close",
    "volume",
    "quote_volume",
    "taker_buy_volume",
    "taker_buy_quote_volume",
    "trade_count",
)
FEATURE_COLUMNS = (
    "open",
    "high",
    "low",
    "close",
    "volume",
    "quote_volume",
    "taker_buy_volume",
    "taker_sell_volume",
    "taker_buy_quote_volume",
    "taker_sell_quote_volume",
    "delta_volume",
    "delta_quote_volume",
    "trade_count",
    "atr14",
    "natr14",
    "boll_mid",
    "boll_upper",
    "boll_lower",
    "boll_width",
    "boll_pos",
    "ret_5",
    "ma99",
    "std20",
    "buy_ratio",
    "delta_ratio",
)
FEATURE_SCHEMA = pa.schema(
    [("instrument_id", pa.string()), ("bar_type", pa.string())]
    + [(name, pa.int64() if name == "trade_count" else pa.float64()) for name in FEATURE_COLUMNS]
    + [("type", pa.string()), ("ts_event", pa.int64()), ("ts_init", pa.int64())],
)


@customdataclass
class BarFeatures(Data):
    """一个已闭合周期的行情与指标；滚动指标预热不足时为 None。"""

    instrument_id: InstrumentId
    bar_type: str
    open: float
    high: float
    low: float
    close: float
    volume: float
    quote_volume: float
    taker_buy_volume: float
    taker_sell_volume: float
    taker_buy_quote_volume: float
    taker_sell_quote_volume: float
    delta_volume: float
    delta_quote_volume: float
    trade_count: int
    atr14: float | None
    natr14: float | None
    boll_mid: float | None
    boll_upper: float | None
    boll_lower: float | None
    boll_width: float | None
    boll_pos: float | None
    ret_5: float | None
    ma99: float | None
    std20: float | None
    buy_ratio: float | None
    delta_ratio: float | None

    _schema = FEATURE_SCHEMA


def _bounds(day: date) -> tuple[int, int]:
    start = int(datetime.combine(day, datetime.min.time(), UTC).timestamp()) * 1_000_000_000
    return start, start + DAY_NS


def feature_path(catalog: ParquetDataCatalog, bar_type: str, day: date) -> Path:
    start, end = _bounds(day)
    return Path(catalog._make_path(BarFeatures, bar_type)) / _timestamps_to_filename(start, end - 1)


def _digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def _aggregate(frame: pd.DataFrame) -> pd.DataFrame:
    return frame.groupby(level=0, sort=True).agg(
        **{
            name: (name, operation)
            for name, operation in (
                ("open", "first"),
                ("high", "max"),
                ("low", "min"),
                ("close", "last"),
                ("volume", "sum"),
                ("quote_volume", "sum"),
                ("taker_buy_volume", "sum"),
                ("taker_buy_quote_volume", "sum"),
                ("trade_count", "sum"),
            )
        },
    )


def aggregate_feature_archive(
    archive: SyncedArchive,
    intervals: tuple[str, ...],
    *,
    chunk_rows: int = CSV_CHUNK_ROWS,
) -> dict[str, pd.DataFrame]:
    """一次分块扫描归档，保留真实 quote_quantity 和主动成交方向。"""
    periods = {
        interval: int(interval_delta(interval).total_seconds() * 1000) for interval in intervals
    }
    parts: dict[str, list[pd.DataFrame]] = {interval: [] for interval in intervals}
    start, end = _bounds(archive.spec.day)
    previous_time = previous_id = None
    for chunk in iter_trade_archive(archive.path, chunk_rows):
        first_time, last_time = int(chunk.timestamp.iloc[0]), int(chunk.timestamp.iloc[-1])
        first_id, last_id = int(chunk.trade_id.iloc[0]), int(chunk.trade_id.iloc[-1])
        if first_time * 1_000_000 < start or last_time * 1_000_000 >= end:
            raise DataValidationError("Trade timestamp 超出归档标注的 UTC 日期")
        if previous_time is not None and first_time < previous_time:
            raise DataValidationError("Trade timestamp 跨数据块倒序")
        if previous_id is not None and first_id <= previous_id:
            raise DataValidationError("Trade ID 跨数据块重复或倒序")
        previous_time, previous_id = last_time, last_id
        values = pd.DataFrame(
            {
                "open": chunk.price,
                "high": chunk.price,
                "low": chunk.price,
                "close": chunk.price,
                "volume": chunk.quantity,
                "quote_volume": chunk.quote_quantity,
                "taker_buy_volume": chunk.quantity.where(~chunk.buyer_maker, 0.0),
                "taker_buy_quote_volume": chunk.quote_quantity.where(~chunk.buyer_maker, 0.0),
                "trade_count": 1,
            }
        )
        for interval, period in periods.items():
            values.index = (chunk.timestamp.to_numpy() // period) * period
            parts[interval].append(_aggregate(values))
    result = {}
    for interval, frames in parts.items():
        if not frames:
            raise DataValidationError("Trade 归档没有数据")
        frame = _aggregate(pd.concat(frames))
        frame.index = (frame.index + periods[interval] - 1) * 1_000_000
        frame.index.name = "ts_event"
        result[interval] = frame
    return result


def _calculate_segment(frame: pd.DataFrame, state: dict) -> tuple[pd.DataFrame, dict]:
    """一个连续时间段的向量化滚动计算，ATR 保存精确的 Wilder 递推状态。"""
    history = state.get("closes", [])
    closes = pd.Series([*history, *frame.close.to_numpy()], dtype="float64")
    offset = len(history)
    output = frame.copy()
    output["boll_mid"] = closes.rolling(20).mean().iloc[offset:].to_numpy()
    output["std20"] = closes.rolling(20).std(ddof=0).iloc[offset:].to_numpy()
    output["ma99"] = closes.rolling(99).mean().iloc[offset:].to_numpy()
    output["ret_5"] = (closes / closes.shift(5) - 1).iloc[offset:].to_numpy()
    previous = closes.shift(1).iloc[offset:].to_numpy()
    tr = np.fmax.reduce(
        [
            (frame.high - frame.low).to_numpy(),
            np.abs(frame.high.to_numpy() - previous),
            np.abs(frame.low.to_numpy() - previous),
        ]
    )
    atr = np.full(len(frame), np.nan)
    prior_atr = state.get("atr")
    seed = state.get("tr_seed", [])
    if prior_atr is not None:
        atr = pd.Series([prior_atr, *tr]).ewm(alpha=1 / 14, adjust=False).mean().iloc[1:].to_numpy()
        seed = []
    elif len(seed) + len(tr) >= 14:
        needed = 14 - len(seed)
        initial = float(np.mean([*seed, *tr[:needed]]))
        atr[needed - 1 :] = (
            pd.Series([initial, *tr[needed:]])
            .ewm(
                alpha=1 / 14,
                adjust=False,
            )
            .mean()
            .to_numpy()
        )
        seed = []
    else:
        seed = [*seed, *tr.tolist()]
    output["atr14"] = atr
    output["natr14"] = 100 * output.atr14 / output.close
    output["boll_upper"] = output.boll_mid + 2 * output.std20
    output["boll_lower"] = output.boll_mid - 2 * output.std20
    band_range = output.boll_upper - output.boll_lower
    output["boll_width"] = band_range / output.boll_mid.replace(0, np.nan)
    output["boll_pos"] = (output.close - output.boll_lower) / band_range.replace(0, np.nan)
    output["taker_sell_volume"] = output.volume - output.taker_buy_volume
    output["taker_sell_quote_volume"] = output.quote_volume - output.taker_buy_quote_volume
    output["delta_volume"] = output.taker_buy_volume - output.taker_sell_volume
    output["delta_quote_volume"] = output.taker_buy_quote_volume - output.taker_sell_quote_volume
    output["buy_ratio"] = output.taker_buy_volume / output.volume.replace(0, np.nan)
    output["delta_ratio"] = output.delta_volume / output.volume.replace(0, np.nan)
    next_state = {
        "closes": closes.iloc[-99:].tolist(),
        "atr": float(atr[-1]) if np.isfinite(atr[-1]) else None,
        "tr_seed": seed,
        "last_ts": int(frame.index[-1]),
    }
    return output.loc[:, FEATURE_COLUMNS], next_state


def calculate_features(
    frame: pd.DataFrame,
    interval: str,
    state: dict | None = None,
) -> tuple[pd.DataFrame, dict]:
    """只使用当前和过去的闭合 K 线；任何时间缺口都重新预热。"""
    if frame.empty or not frame.index.is_monotonic_increasing or frame.index.has_duplicates:
        raise DataValidationError("特征输入必须是非空、严格递增的 K 线")
    period = int(interval_delta(interval).total_seconds() * 1_000_000_000)
    state = state or {}
    if state.get("last_ts") != int(frame.index[0]) - period:
        state = {}
    boundaries = np.flatnonzero(np.diff(frame.index.to_numpy()) != period) + 1
    outputs = []
    for index, segment in enumerate(np.split(np.arange(len(frame)), boundaries)):
        output, state = _calculate_segment(frame.iloc[segment], state if index == 0 else {})
        outputs.append(output)
    return pd.concat(outputs), state


class FeatureStore:
    """检查整个前序依赖链，避免历史补写或重建后静默读取失效指标。"""

    def __init__(self, catalog: ParquetDataCatalog) -> None:
        self.catalog = catalog
        self.validated: dict[tuple[str, date], dict | None] = {}
        self.bar_files: dict[str, list[tuple[int, int, str, int, int]]] = {}

    def bar_fingerprint(self, bar_type: str, day: date) -> str:
        if bar_type not in self.bar_files:
            files = []
            for path in sorted(Path(self.catalog._make_path(Bar, bar_type)).glob("*.parquet")):
                bounds = _parse_filename_timestamps(path.name)
                if bounds is not None:
                    stat = path.stat()
                    files.append((*bounds, path.name, stat.st_size, stat.st_mtime_ns))
            self.bar_files[bar_type] = files
        start, end = _bounds(day)
        files = [item for item in self.bar_files[bar_type] if item[0] < end and item[1] >= start]
        if not files:
            raise ConversionError(f"特征缺少对应的标准 Bar：{bar_type} {day}")
        return _digest(files)

    def metadata(self, bar_type: str, day: date) -> dict | None:
        path = feature_path(self.catalog, bar_type, day)
        if not path.exists():
            return None
        try:
            metadata = pq.read_metadata(path).metadata or {}
            value = json.loads(metadata[b"pipeline_features"])
            if not isinstance(value, dict) or not isinstance(value.get("state"), dict):
                raise TypeError("无效的特征元数据")
            return value
        except (KeyError, TypeError, ValueError, OSError, pa.ArrowException) as exc:
            raise ConversionError(f"特征文件无效，请重建：{path}") from exc

    def valid_metadata(self, bar_type: str, day: date) -> dict | None:
        pending = []
        cursor = day
        while (bar_type, cursor) not in self.validated:
            meta = self.metadata(bar_type, cursor)
            if meta is None:
                self.validated[bar_type, cursor] = None
                break
            pending.append((cursor, meta))
            cursor -= timedelta(days=1)
        parent = self.validated[bar_type, cursor]
        for current_day, meta in reversed(pending):
            expected_parent = parent["digest"] if parent else None
            if (
                meta.get("version") != FEATURE_VERSION
                or meta.get("parent") != expected_parent
                or meta.get("bar_fingerprint") != self.bar_fingerprint(bar_type, current_day)
                or meta.get("digest") != _digest({k: v for k, v in meta.items() if k != "digest"})
            ):
                raise ConversionError(
                    f"特征缓存已失效：{bar_type} {current_day}；"
                    "请从该日开始重新运行 prepare_data，直到需要读取的结束日期",
                )
            self.validated[bar_type, current_day] = parent = meta
        return self.validated[bar_type, day]

    def write(
        self,
        bar_type: str,
        day: date,
        frame: pd.DataFrame,
        metadata: dict,
    ) -> None:
        frame = frame.reset_index()
        frame["bar_type"] = bar_type
        frame["instrument_id"] = str(BarType.from_str(bar_type).instrument_id)
        frame["type"] = "BarFeatures"
        frame["ts_init"] = frame.ts_event
        metadata["digest"] = _digest(metadata)
        table = pa.Table.from_pandas(frame, schema=FEATURE_SCHEMA, preserve_index=False)
        table = table.replace_schema_metadata({b"pipeline_features": json.dumps(metadata).encode()})
        path = feature_path(self.catalog, bar_type, day)
        path.parent.mkdir(parents=True, exist_ok=True)
        with NamedTemporaryFile(dir=path.parent, prefix=".features-", delete=False) as temporary:
            temporary_path = Path(temporary.name)
        try:
            pq.write_table(table, temporary_path, compression="zstd", row_group_size=5000)
            os.replace(temporary_path, path)
        finally:
            temporary_path.unlink(missing_ok=True)
        self.validated[bar_type, day] = metadata


def prepare_bar_features(
    archives: list[SyncedArchive],
    catalog: ParquetDataCatalog,
    *,
    raw_dir: Path,
    state_dir: Path,
    bar_intervals: tuple[str, ...],
    force: bool = False,
    chunk_rows: int = CSV_CHUNK_ROWS,
) -> None:
    """在行情转换成功后补建请求周期；已有有效缓存不读取 trades。"""
    store = FeatureStore(catalog)
    for archive in sorted(archives, key=lambda value: (value.spec.day, value.spec.symbol)):
        record = read_record(record_path_for(archive.path, raw_dir, state_dir))
        if not record or record.get("status") != "ready":
            raise ConversionError(f"行情尚未就绪：{archive.spec.source_path}")
        pending = {}
        for interval in bar_intervals:
            bar_type = bar_type_for(archive.spec.symbol, interval)
            parent = store.valid_metadata(bar_type, archive.spec.day - timedelta(days=1))
            item = record.get("bars", {}).get(interval, {})
            checksum = item.get("source_checksum", record.get("source_checksum"))
            expected = {
                "version": FEATURE_VERSION,
                "source_checksum": checksum,
                "parent": parent["digest"] if parent else None,
                "bar_fingerprint": store.bar_fingerprint(bar_type, archive.spec.day),
            }
            existing = None if force else store.metadata(bar_type, archive.spec.day)
            if not force and existing and all(existing.get(k) == v for k, v in expected.items()):
                store.valid_metadata(bar_type, archive.spec.day)
                continue
            if checksum != record.get("source_checksum"):
                raise ConversionError(f"特征与旧 Bar 来源不一致，请 --force 重建：{bar_type}")
            pending[interval] = (expected, parent)
        if not pending:
            continue
        # 检查当前 ZIP 与已物化行情使用同一个源；不允许混合旧 OHLCV 和新成交量。
        if read_archive_checksum(archive.path) != record.get("source_checksum"):
            raise ConversionError("源归档已变化，生成特征前请 --force 重建对应行情")
        frames = aggregate_feature_archive(archive, tuple(pending), chunk_rows=chunk_rows)
        for interval, (metadata, parent) in pending.items():
            frame, state = calculate_features(
                frames[interval],
                interval,
                parent["state"] if parent else None,
            )
            metadata["state"] = state
            bar_type = bar_type_for(archive.spec.symbol, interval)
            store.write(bar_type, archive.spec.day, frame, metadata)
            print(f"已写入 {len(frame)} 根指标：{bar_type} {archive.spec.day}")


def read_bar_features(
    catalog: ParquetDataCatalog,
    symbol: str,
    interval: str,
    start: datetime,
    end: datetime,
    *,
    columns: list[str] | None = None,
) -> pd.DataFrame:
    """校验依赖链并按列读取；范围左闭右开，缺失或失效的数据明确报错。"""
    start, end = as_utc(start), as_utc(end)
    if start >= end:
        raise ValueError("开始时间必须早于结束时间")
    selected = list(dict.fromkeys(["ts_event", *(FEATURE_COLUMNS if columns is None else columns)]))
    if any(name not in FEATURE_SCHEMA.names for name in selected):
        raise ValueError("未知的指标列")
    bar_type = bar_type_for(normalize_symbol(symbol), interval)
    store = FeatureStore(catalog)
    day, last_day = start.date(), (end - timedelta(microseconds=1)).date()
    frames = []
    while day <= last_day:
        if store.valid_metadata(bar_type, day) is None:
            raise ConversionError(f"缺少指标数据，请运行 prepare_data：{bar_type} {day}")
        frames.append(
            pq.read_table(feature_path(catalog, bar_type, day), columns=selected).to_pandas()
        )
        day += timedelta(days=1)
    frame = pd.concat(frames, ignore_index=True)
    start_ns, end_ns = int(start.timestamp() * 1e9), int(end.timestamp() * 1e9)
    return frame.loc[(frame.ts_event >= start_ns) & (frame.ts_event < end_ns)].reset_index(
        drop=True
    )
