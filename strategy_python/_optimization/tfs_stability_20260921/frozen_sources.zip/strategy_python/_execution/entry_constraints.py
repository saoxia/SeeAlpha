"""Instrument bounds for opening orders, including margin backtests.

Nautilus' margin-account risk path currently returns before instrument notional
checks. Never increase a risk-approved quantity just to reach an exchange minimum.
Reduce-only exits deliberately do not use this opening-order guard.
"""

from decimal import Decimal


def opening_order_allowed(instrument, quantity, price) -> bool:
    qty = quantity.as_decimal() if hasattr(quantity, "as_decimal") else Decimal(str(quantity))
    px = price.as_decimal() if hasattr(price, "as_decimal") else Decimal(str(price))
    if not qty.is_finite() or not px.is_finite() or qty <= 0 or px <= 0:
        return False
    if instrument.min_quantity is not None and qty < instrument.min_quantity.as_decimal():
        return False
    if instrument.max_quantity is not None and qty > instrument.max_quantity.as_decimal():
        return False
    notional = instrument.notional_value(instrument.make_qty(qty), instrument.make_price(px))
    for limit, minimum in ((instrument.min_notional, True), (instrument.max_notional, False)):
        if limit is not None:
            if limit.currency != notional.currency:
                return False
            if minimum and notional.as_decimal() < limit.as_decimal():
                return False
            if not minimum and notional.as_decimal() > limit.as_decimal():
                return False
    return True
