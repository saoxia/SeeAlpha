# TFL_optimized 独立新版本

来源：fourth_clock40_budget_half。所有策略参数已写入本包Config默认值；create_config/create_strategy使用BTC分钟行情及明确起始时间。

选择理由：40分钟信号与半预算在完整历史收益和回撤均优于30分钟及费用过滤组合，68活跃月；20/30/40邻域已保留。仍亏损，且信号分布变化与历史选择偏差尚存。

完整配置、参数变化和研究回放来源见profile.json。历史研究含训练重叠和选择偏差，不代表未来盈利或实盘批准。
